export {default as StructureMenuWidget} from './StructureMenuWidget'
